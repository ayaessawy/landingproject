/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 */

const unorderlists=document.getElementById("navbar__list");     /* select unorder list*/
const sections=document.querySelectorAll('section');           /* select all sections */
const fragment = document.createDocumentFragment();
let header1=document.querySelector('.navbar__menu'); 
let headerofsection=document.querySelector('h2');
let headerofsectionSS=document.querySelectorAll('h2');
let x;
let y;
const nav=document.querySelector('.page__header'); 
const button=document.getElementById("btn")
                    

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/


 for (let index=0;index<=sections.length-1;index++){  //for loop of sections//  
                             /* create mew list element   and append new element  lists to unorder list*/
   
                        let newlist=document.createElement("li");               /*   create list element*/ 
                        let newanchor=document.createElement("a");               /*   create anchor element*/ 
                        let txt=sections[index].getAttribute('data-nav');         /*   get attribute data-nav totxt*/ 
                        newanchor.textContent=txt;                                 /*   append txt or data-nav attribute to anchor*/ 
                                    
                        newanchor.classList.add("menu__link");                     /*add class list  menu__link to anchor*/
                        newlist.append(newanchor);                                /*append anchor to list element */
                        fragment.append(newlist);                                 /*append  listto fragement  */
                        unorderlists.append(fragment);                            /*append fragement to unorderlist  */      
                                newanchor.addEventListener("click",function(){  
                                                 nav.style.display="block";
                                                y=sections[index].getBoundingClientRect().top;
                                                
                                                       
                                                window.scroll({
                                                        top:y+document.scrollingElement.scrollTop,
                                                       
                                                            
                                                        behavior: "smooth"
                                                }); 
                                               
                                                y=sections[index].getBoundingClientRect().top;
                                          
                                                 newanchor.classList.add("scrollsection");
                                               
                                                 let anchors=document.querySelectorAll(".menu__link");
                                        
                                          anchors.forEach((anchor,index)=>{
                                                        if(anchor.classList.contains("scrollsection")){
                                                               anchors[index].classList.add("active")
                                                               anchors[index].classList.remove("scrollsection")}
                                                        else{ anchors[index].classList.remove("active")}
                                                                                                                     
                                                                                                                     
                                                                                                                     
                                                                                                                      }
                                                                                                                     
                                                                                                                      )
                                                           
                                                                       
                                                                   
                              
                                                  
                                                                                
                                                                                
                                               
                                     

                                                

                                                                                          })
                          
                                             
                                             

                                                        



                     
 }

 let anchors=document.querySelectorAll(".menu__link");
 window.onload =function() {anchors[0].classList.add("active")} 



 ////////////////////////////////////////////////////////////////////
 let prevscroll=window.pageYOffset;                  
 let sectionstop=[];  
 let nextscroll;
 let sectionbottom=[];
 
  


                                                                 





 ///////////////////////////////////      
 
                 
  
 document.addEventListener( "scroll",scrolling,true)
 document.addEventListener( "click",function(){
        
       document.scrollingElement.scrollTop=0
       ,true})

 
 /////////////////////////////
      function   scrolling(){
        nextscroll=window.pageYOffset; 
        if( nextscroll>prevscroll){
                nav.style.display="none";
                button.style.display="block"
           
               

      }else{ nav.style.display="block";
            button.style.display="none"
               }
            
               
              sections.forEach((section,position)=>{
                     
                            let headder=section.firstElementChild.firstElementChild;
                            let headerheight=headder.offsetHeight;
                                   sectionstop[position]=section.getBoundingClientRect().top+headerheight+document.scrollingElement.scrollTop;
                                   sectionbottom[position]=section.getBoundingClientRect().bottom+headerheight+document.scrollingElement.scrollTop;
                                   if(nextscroll<sectionstop[position] &&sectionbottom[position] >nextscroll){headder.classList.add("activee")
                                   
                            
                            }
                                   else{headder.classList.remove("activee") 
                                   }
                            
                            })
        
    
   
    
        
            
              
}


/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav


// Add class 'active' to section when near top of viewport


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active



 /*function   scrolling(){
        nextscroll=window.pageYOffset; 
        if( nextscroll>prevscroll){
                nav.style.display="none";
    
               

      }else{ nav.style.display="block";}


      for(let position=0;position<sections.length;position++){
        let headder=sections[position].firstElementChild.firstElementChild;
        let headerheight=headder.offsetHeight;
              sectiontop=sections[position].getBoundingClientRect().top+headerheight+document.scrollingElement.scrollTop;
              if(nextscroll<=sectiontop){headder.classList.add("activee")
              
            
             }
              else{headder.classList.remove("activee") 
              }
              console.log(sectiontop[position])
           }
        
    
   
    
        
            
              
}*/
